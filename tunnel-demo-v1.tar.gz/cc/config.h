
#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

typedef std::multimap<std::string, std::pair<int,std::string>> conf_map_t;

int init_listen_port();

#endif
