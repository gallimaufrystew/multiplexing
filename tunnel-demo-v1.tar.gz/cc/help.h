/*
 * help.h
 *
 *  Created on: Mar 26, 2018
 *      Author:
 */

#ifndef HELP_H_
#define HELP_H_

#ifdef _WIN32
    #define WIN32_LEAN_AND_MEAN
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <windows.h>
    #include <process.h>
#else
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <signal.h>
    #include <sys/un.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <unistd.h>
    #include <netdb.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <openssl/ssl.h>
#include <openssl/err.h>

#ifdef _WIN32
    #include "openssl\applink.c"
#endif

typedef std::unordered_map<int, std::string> fd_desc_map;
typedef std::unordered_map<int, int> fd_port_map;

#define CUSTOM_EXT_TYPE_1000 10000

typedef struct {
    std::string ssl_host;
    int ssl_port;
    bool verify_peer;
    bool connected;
    int fd;
    SSL_CTX *ssl_ctx;
    SSL *ssl;
} ssl_conn_t;

void init_libssl();
int server_open_socket(int port, fd_port_map &port_maps);
int client_open_ssl(ssl_conn_t *ssl_con);
int init_config(std::vector<int> &ports);
int init_ssl_config(ssl_conn_t *ssl_config);
int handle_ssl_read(ssl_conn_t *ssl_con);
int handle_read_client(int fd, ssl_conn_t *ssl_con, fd_port_map &port_maps);
int handle_accept(int fd, fd_port_map &port_maps);

#endif /* HELP_H_ */
