
#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

int init_port_mapping();

#endif
